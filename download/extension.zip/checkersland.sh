#!/bin/sh

java -Xmx512m -jar checkersland.jar
