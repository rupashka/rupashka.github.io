#!/bin/sh

java -Xmx512m -Xbootclasspath/a:jgoodies-common-1.4.0.jar:jgoodies-looks-2.5.2.jar -Dswing.defaultlaf=com.jgoodies.looks.plastic.PlasticXPLookAndFeel -jar ../../checkersland.jar
