#!/bin/sh

#
# There are a lot other substance look and feels:
#
# SubstanceRavenLookAndFeel
# SubstanceAutumnLookAndFeel
# SubstanceCremeLookAndFeel
# SubstanceBusinessBlueSteelLookAndFeel
# SubstanceBusinessBlackSteelLookAndFeel
# SubstanceEmeraldDuskLookAndFeel
# SubstanceNebulaLookAndFeel
# SubstanceSaharaLookAndFeel
# SubstanceOfficeBlue2007LookAndFeel
# SubstanceBusinessLookAndFeel
# SubstanceNebulaBrickWallLookAndFeel
# SubstanceChallengerDeepLookAndFeel
# SubstanceCremeCoffeeLookAndFeel
# SubstanceMistSilverLookAndFeel
# SubstanceOfficeSilver2007LookAndFeel
# SubstanceRavenGraphiteLookAndFeel
# SubstanceRavenGraphiteGlassLookAndFeel
# SubstanceMagmaLookAndFeel
# SubstanceModerateLookAndFeel
# SubstanceMistAquaLookAndFeel

java -Xmx512m -Xbootclasspath/a:substance-6.1.jar:trident-1.2.jar -Dswing.defaultlaf=org.pushingpixels.substance.api.skin.SubstanceBusinessBlackSteelLookAndFeel -jar ../../checkersland.jar
