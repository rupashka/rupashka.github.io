#!/bin/sh

java -Xmx512m -Xbootclasspath/a:napkinlaf-1.2.jar -Dswing.defaultlaf=net.sourceforge.napkinlaf.NapkinLookAndFeel -jar ../../checkersland.jar
