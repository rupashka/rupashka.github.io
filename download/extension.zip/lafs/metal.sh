#!/bin/sh

java -Xmx512m -Dswing.defaultlaf=javax.swing.plaf.metal.MetalLookAndFeel -jar ../checkersland.jar
